package com.ebooks.yifantian.myapplication;

/**
 * Created by yifantian on 5/29/17.
 */


import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ebooks.yifantian.myapplication.R;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class EbookSearch extends AppCompatActivity {

    private SearchEbook mAuthTask = null;
    private ArrayList<String> showBooks = new ArrayList<String>();
    private int countPage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ebook_search);                 // link to layout?
    }

    public void searchEbooks(View view)
    {
        EditText et = (EditText) findViewById(R.id.ebook_title);
        String title = et.getText().toString();
        mAuthTask = new SearchEbook(title,this.showBooks);                 // use
        mAuthTask.execute((Void) null);                     // this one use onPostExecute?
        showBooks = mAuthTask.ebooks;
        System.out.println("the length of books after excution of searchMovies:"+this.showBooks.size());
    }

    public void showBooksNext(View view)
    {

        countPage++;
        if( (countPage+1)*5>showBooks.size())
        {
            countPage = 0;
        }
        TextView banner = (TextView)findViewById(R.id.Ebook_banner);
        banner.setText("Results for pages " + countPage);
        if(banner.getVisibility() == View.INVISIBLE)
            banner.setVisibility(View.VISIBLE);

        LinearLayout ll = (LinearLayout) findViewById(R.id.ebook_list);             // show on screen

        if(ll.getChildCount() > 0)
            ll.removeAllViews();

        System.out.println("the output for limit num of books");
        for (int i = countPage * 5; i < countPage * 5 + 5; i++) {

            String title = showBooks.get(i);
            //System.out.println(title);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            TextView tv = new TextView(getApplicationContext());
            tv.setLayoutParams(lp);
            tv.setText(title);
            tv.setTextSize(20);
            Random rnd = new Random();
            int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            tv.setTextColor(color);
            ll.addView(tv);
            TextView tv1 = new TextView(getApplicationContext());
            tv1.setText("------------------------------------------------------------------");
            tv1.setTextColor(color);
            ll.addView(tv1);
        }

        System.out.println("countpage: "+countPage);
        if( (countPage+2)*5>showBooks.size())               // control view of next
        {
            System.out.println("showBooks should be INVISIBLE");
            System.out.println(countPage+" "+(countPage+2)*5+" "+showBooks.size());
            TextView Next = (TextView)findViewById(R.id.send_next_button);
            if(Next.getVisibility() == View.VISIBLE)
                Next.setVisibility(View.INVISIBLE);
        }

        // just for test
//        if(countPage==2) {
//            TextView Next = (TextView)findViewById(R.id.send_next_button);
//            if(Next.getVisibility() == View.VISIBLE)
//                Next.setVisibility(View.INVISIBLE);
//        }

        if(countPage>0)                                     // control view of prev
        {
            System.out.println("Prev should be VISIBLE");
            System.out.println(countPage+" "+(countPage+2)*5+" "+showBooks.size());
            TextView Prev = (TextView)findViewById(R.id.send_prev_button);
            if(Prev.getVisibility() == View.INVISIBLE)
                Prev.setVisibility(View.VISIBLE);
        }

    }


    public void showBooksPre(View view)
    {

        if(countPage > 0)
        {
            countPage--;
//            countPage = (showBooks.size() - 1) / 5;
            TextView banner = (TextView)findViewById(R.id.Ebook_banner);
            banner.setText("Results for pages: " + countPage);
            if(banner.getVisibility() == View.INVISIBLE)
                banner.setVisibility(View.VISIBLE);

            LinearLayout ll = (LinearLayout) findViewById(R.id.ebook_list);             // show on screen

            if(ll.getChildCount() > 0)
                ll.removeAllViews();

            System.out.println("the pre Output for limit num of books");
            for (int i = countPage * 5; i < countPage * 5 + 5; i++) {

                String title = showBooks.get(i);
                //System.out.println(title);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                TextView tv = new TextView(getApplicationContext());
                tv.setLayoutParams(lp);
                tv.setText(title);
                tv.setTextSize(20);
                Random rnd = new Random();
                int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                tv.setTextColor(color);
                ll.addView(tv);
                TextView tv1 = new TextView(getApplicationContext());
                tv1.setText("------------------------------------------------------------------");
                tv1.setTextColor(color);
                ll.addView(tv1);
            }
            System.out.println("finish output for limit num of books");

            if(countPage == 0)               // control view of next
            {
                TextView prev = (TextView) findViewById(R.id.send_prev_button);
                if (prev.getVisibility() == View.VISIBLE)
                    prev.setVisibility(View.INVISIBLE);
            }

        } else
        {
            System.out.println("something is wrong!");
        }

//        TextView Next = (TextView)findViewById(R.id.send_next_button);
//        if(Next.getVisibility() == View.INVISIBLE)
//            Next.setVisibility(View.VISIBLE);

        if( (countPage+2)*5<showBooks.size())               // control view of next
        {
            System.out.println("next should be VISIBLE");
            System.out.println(countPage+" "+(countPage+2)*5+" "+showBooks.size());
            TextView Next = (TextView)findViewById(R.id.send_next_button);
            if(Next.getVisibility() == View.INVISIBLE)
                Next.setVisibility(View.VISIBLE);
        }

    }

    public void addMovies(ArrayList<String> ebooks)
    {

        System.out.println("at add movies");
        this.showBooks.clear();
        for(String title: ebooks)
        {
            this.showBooks.add(title);
        }
        System.out.println("the length of ebooks after adding movies:"+this.showBooks.size());
    }

    public class SearchEbook extends AsyncTask<Void, Void, ArrayList<String>> {

        private final String mTitle;

        public ArrayList<String> ebooks = new ArrayList<String>();

        SearchEbook(String title,ArrayList<String> books) {
            mTitle = title;
            ebooks = books;
        }           // the constructor

        @Override
        protected ArrayList<String> doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            StringBuilder sb = new StringBuilder();
            JSONObject json = null;
            try {
                String query = URLEncoder.encode(mTitle, "utf-8");
//                URL url = new URL("http://fabflix.xyz:8080/project4//AndroidMovieSearch?title="+query);
                String urlstring = "http://www.smartanteater.com:8080/Android/AndroidEbookSearch?title="+query;
                System.out.println(urlstring);
                URL url = new URL(urlstring);
                // Simulate network access.
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Accept", "application/json");
                urlConnection.connect();

                int status = urlConnection.getResponseCode();

                switch (status) {
                    case 200:
                    case 201:
                        BufferedReader br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line + "\n");
                        }
                        System.out.println("response: "+sb.toString());
                        br.close();
                        json = new JSONObject(sb.toString());

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            ArrayList<String> result = new ArrayList<String>();
//            if (result.size() == 0) {
//                Toast.makeText(MovieSearch.this, "Did not found!", Toast.LENGTH_SHORT).show();
//            }
            buildList(json, result);
            System.out.println("the length of search books:"+result.size());
            if (result.size() == 0) {
                System.out.println("did not found");
//                Toast.makeText(MovieSearch.this, "Did not found!", Toast.LENGTH_SHORT).show();
                TextView banner = (TextView)findViewById(R.id.Ebook_banner);
            }
            addMovies(result);
            return result;
        }

        private void buildList(JSONObject json, ArrayList<String> res)              // retrieve the list
        {
            Iterator<String> iter = json.keys();
            while(iter.hasNext())
            {
                try {
                    //System.out.println("books: "+(String)json.get(iter.next()));
                    res.add((String)json.get(iter.next()));
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        }
        @Override
        protected void onPostExecute(ArrayList<String> books) {
            mAuthTask = null;
            TextView banner = (TextView)findViewById(R.id.Ebook_banner);
            LinearLayout ll = (LinearLayout) findViewById(R.id.ebook_list);             // show on screen

            if(ll.getChildCount() > 0)
                ll.removeAllViews();

            if(books.size()==0) {
                banner.setText("Did not found result for: " + mTitle);
                if(banner.getVisibility() == View.INVISIBLE)
                    banner.setVisibility(View.VISIBLE);

                TextView Next = (TextView)findViewById(R.id.send_next_button);
                if(Next.getVisibility() == View.VISIBLE)
                    Next.setVisibility(View.INVISIBLE);

                TextView Prev = (TextView)findViewById(R.id.send_prev_button);
                if(Prev.getVisibility() == View.VISIBLE)
                    Prev.setVisibility(View.INVISIBLE);

            } else {
                banner.setText("Search Results for Title: " + mTitle+" at page "+0);
                if(banner.getVisibility() == View.INVISIBLE)
                    banner.setVisibility(View.VISIBLE);

                //for(String title: movies)
//                for(int i = 0;i<5;i++)
                int showlength = 0;
                if (books.size()<5)
                {
                    showlength=books.size();

                    TextView Next = (TextView)findViewById(R.id.send_next_button);
                    if(Next.getVisibility() == View.VISIBLE)
                        Next.setVisibility(View.INVISIBLE);

                    TextView Prev = (TextView)findViewById(R.id.send_prev_button);
                    if(Prev.getVisibility() == View.VISIBLE)
                        Prev.setVisibility(View.INVISIBLE);


                } else {

                    TextView Next = (TextView)findViewById(R.id.send_next_button);
                    if(Next.getVisibility() == View.INVISIBLE)
                        Next.setVisibility(View.VISIBLE);
                    showlength=5;
                }
                for(int i = 0;i<showlength;i++)
                {
                    String title = books.get(i);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                    TextView tv = new TextView(getApplicationContext());
                    tv.setLayoutParams(lp);
                    tv.setText(title);
                    Random rnd = new Random();
                    int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
//                    tv.setTextColor(Color.BLACK);
                    tv.setTextColor(color);
                    tv.setTextSize(20);
                    ll.addView(tv);
                    TextView tv1 = new TextView(getApplicationContext());
                    tv1.setText("------------------------------------------------------------------");
                    tv1.setTextColor(color);
                    ll.addView(tv1);
                }
            }
        }
    }
}
